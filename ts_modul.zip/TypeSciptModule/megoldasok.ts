export { };
//1. feladat
function Rng(alsoHatar: number, felsoHatar: number): number {
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
}
//2.feladat
//3.feladat
//4.fealdat
//5.feladat