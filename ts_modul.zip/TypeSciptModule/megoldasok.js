"use strict";
exports.__esModule = true;
//1. feladat
function Rng(alsoHatar, felsoHatar) {
    return Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar;
}
//2.feladat
//function TombGenerator(meret, alsoHatar, felsoHatar): number[] {}
//3.feladat
//function Duplazo(VizsgaltTomb: number): number[] {}
//4.fealdat
//5.feladat
